package org.cap.dao;

public interface IBusPassDAO {

}
