package org.cap.service;

public interface IBusPassService {

}
