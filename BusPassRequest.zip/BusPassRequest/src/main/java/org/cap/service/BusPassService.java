package org.cap.service;

public class BusPassService {

}
